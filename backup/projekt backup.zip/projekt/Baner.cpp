#include "Header.h"

Baner::Baner()
{

}
