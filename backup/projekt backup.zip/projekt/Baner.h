#ifndef BANER_H
#define BANER_H


class Baner
{
public:
    Baner();
};

#endif // BANER_H
